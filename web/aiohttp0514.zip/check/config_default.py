configs = {
    'debug': True,
    'session': {
        'secret': 'czaOrz'
    },
    'db': {
        'host': 'localhost',
        'port': 3306,
        'user': 'root',
        'password': 'cza19950917',
        'db': 'test'
    }
}
