import inspect


def func1(*, name, age, temp='', test=True):
    pass


# params = inspect.signature(func1).parameters
#
# print(params)
# print([j.kind for i,j in params.items()])
# print([j.default for i,j in params.items()])  # 什么都不定义的才是empty

def api_update_blog(id, request, *, name, summary, content):
    return 'hello'

data = {'name': 'test2222211111123',
        'summary': 'this is test 2222211111123',
        'content': 'hello, test 2222211111123',
        'id': '001557741667738a769764da74c43628b3600949e59f5c2000',
        'request': 'aaa'}
print(api_update_blog(**data))  # 只要把参数传进去了，位置是无所谓的吗