def decorator(func=None, args='nice'):
    print(func or 'No1')
    print(args or 'No2')
    def wp(func):
        def wrapper(name, age):
            print('get name: %s' % name)
            return func(name, age)
        return wrapper
    if func:
        print('1, run here')
        if not callable(func):
            raise Exception('Error! not callable')
        #
        return wp(func)  # 没带参数，decorator(test)
    print('2, run here')
    # return必须为一个callable
    return wp  # 带了参数，decorator(args='test')(test)

@decorator#(args='test')
def test(name, age):
    print(name, age, '#################')

test('cza', 123)
